function varargout = jiemian(varargin)
% JIEMIAN M-file for jiemian.fig
%      JIEMIAN, by itself, creates a new JIEMIAN or raises the existing
%      singleton*.
%
%      H = JIEMIAN returns the handle to a new JIEMIAN or the handle to
%      the existing singleton*.
%
%      JIEMIAN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in JIEMIAN.M with the given input arguments.
%
%      JIEMIAN('Property','Value',...) creates a new JIEMIAN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before jiemian_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to jiemian_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help jiemian

% Last Modified by GUIDE v2.5 03-Nov-2021 02:26:28

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @jiemian_OpeningFcn, ...
    'gui_OutputFcn',  @jiemian_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before jiemian is made visible.
function jiemian_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to jiemian (see VARARGIN)

% Choose default command line output for jiemian
handles.output = hObject;
set(gcf,'name','��ϵ΢��:matlab2022  ');
% Update handles structure
guidata(hObject, handles);
clc;
axes(handles.axes2);
imshow(imread('logo.jpg'));
global file;
global I;
global vid;
global P;P=0;
global n;n=0;
set(handles.edit1,'String','10');
set(handles.edit2,'String','0');
set(handles.edit3,'String','0');
set(handles.edit4,'String','0');
set(handles.edit5,'String','0');


% UIWAIT makes jiemian wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = jiemian_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit6,'String','...');
hold off;
global n;n=0;
set(handles.radiobutton1,'value',1);
set(handles.edit1,'String','10');
set(handles.edit3,'String','0');
set(handles.edit4,'String','0');
set(handles.edit5,'String','0');
global P;
if P==8
    global vid;
    axes(handles.axes1);
    I=getsnapshot(vid);
    imshow(I);
    set(handles.edit7,'String','������ͷ����ͼ��');
else
    [filename,pathname]=uigetfile({'*.jpg';'*.bmp';'*.tif';'*.*'},'��ͼ��...');
    if isequal(filename,0)|isequal(pathname,0)
        errordlg('ͼ���ļ�δ�ҵ�','File Error');
    else
        global file;
        global I;
        P=1;
        file=[pathname,filename];
        I=imread(file);
        axes(handles.axes1);
        imshow(I);
        set(handles.edit7,'String','��Ԫ����ԭʼͼ��');
    end
end
set(handles.edit6,'String','OK');
msgbox('΢��:matlab2022');

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit6,'String','...');
hold off;
global file;
global I;
global P;
global n;n=0;
set(handles.radiobutton1,'value',1);
set(handles.edit3,'String','0');
set(handles.edit4,'String','0');
set(handles.edit5,'String','0');
if P==8
    axes(handles.axes1);
    cla reset;
else if P == 0
        errordlg('���ȴ�ͼ��','Warning...');
    else
        P=1;
        I=imread(file);
        axes(handles.axes1);
        imshow(I);
        set(handles.edit7,'String','��Ԫ����ԭʼͼ��');
    end
end
set(handles.edit6,'String','OK');


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit6,'String','...');
global P;
if P == 0
    errordlg('���ȴ�ͼ��','Warning...');
else
    [filename,pathname]=uiputfile({'*.jpg';'*.bmp';'*.tif';'*.*'},'����ͼƬ...','Undefined');
    if ~isequal(filename,0)
        str = [pathname filename];
        px=getframe(handles.axes1);
        cdata = getappdata(gcf,'Timg');
        imwrite(px.cdata,str);
    else errordlg('����ʧ�ܣ�','Warning...');
    end;
end
set(handles.edit6,'String','OK');


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit6,'String','...');
global P;
P=0;
set(handles.edit3,'String','0');
set(handles.edit4,'String','0');
set(handles.edit5,'String','0');
axes(handles.axes1);
cla reset;
closepreview;
set(handles.edit7,'String','�����ȴ�ͼ��');
set(handles.edit6,'String','OK');


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit6,'String','...');
global I;
global P;
switch P
    case 7,errordlg('ͼ���Ѿ���ɶ�ֵ������ֱ�Ӳ���λ��','Warning...');
    case 6,errordlg('ͼ���Ѿ���ǿ�Աȶȣ�������ò�����λ��','Warning...');
    case 5,errordlg('�Ѿ���ȡĿ�꣬������ò�����λ��','Warning...');
    case 4,errordlg('�Ѿ�ѡȡ�궨Ŀ�꣬������ò�����λ��','Warning...');
    case 3,errordlg('ͼ���Ѿ���ɼ���У����������ò�����λ��','Warning...');
    case 2,errordlg('ͼ���Ѿ������ֵ�˲���������ò�����λ��','Warning...');
    case 1,P=2;
        I=rgb2gray(I);                                          %ת��Ϊ�Ҷ�
        I=medfilt2(I,[3 3]);                                     %��ֵ�˲�
        axes(handles.axes1);
        imshow(I);
        set(handles.edit7,'String','����ֵ�˲����Ԫ��ͼ��');
    case 0,errordlg('���ȴ�ͼ��','Warning...');
end
set(handles.edit6,'String','OK');


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit6,'String','...');
global I;
global P;
switch P
    case 7,errordlg('ͼ���Ѿ���ɶ�ֵ������ֱ�Ӳ���λ��','Warning...');
    case 6,errordlg('ͼ���Ѿ���ǿ�Աȶȣ�������ò�����λ��','Warning...');
    case 5,errordlg('�Ѿ���ȡĿ�꣬������ò�����λ��','Warning...');
    case 4,errordlg('�Ѿ�ѡȡ�궨Ŀ�꣬������ò�����λ��','Warning...');
    case 3,errordlg('ͼ���Ѿ���ɼ���У����������ò�����λ��','Warning...');
    case 2,P=3;
        set(handles.edit7,'String','��ѡȡ�ĶԿ��Ƶ㡱');
        cpselect(I,I);
        uiwait;
        input_points = evalin('base', 'input_points');
        base_points = evalin('base', 'base_points');
        mytform=cp2tform(input_points,base_points,'projective');
        I=imtransform(I,mytform);
        axes(handles.axes1);
        imshow(I);
        set(handles.edit7,'String','������У�����Ԫ��ͼ��');
    case 1,errordlg('���Ƚ�����ֵ�˲���','Warning...');
    case 0,errordlg('���ȴ�ͼ��','Warning...');
end
set(handles.edit6,'String','OK');


% --- Executes on button press in pushbutton13.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit6,'String','...');
global I;
global P
switch P
    case 7,errordlg('ͼ���Ѿ���ɶ�ֵ������ֱ�Ӳ���λ��','Warning...');
    case 6,errordlg('ͼ���Ѿ���ǿ�Աȶȣ�������ò�����λ��','Warning...');
    case 5,errordlg('�Ѿ���ȡĿ�꣬������ò�����λ��','Warning...');
    case 4,errordlg('�Ѿ�ѡȡ�궨Ŀ�꣬������ò�����λ��','Warning...');
    case 3,
        B=str2double(get(handles.edit1,'string'));
        if B==0
            errordlg('�궨���Ȳ���Ϊ��,�����룡','Warning...');
        else
            P=4;
            set(handles.edit7,'String','��������궨���Ȳ�ѡȡ�궨Ŀ�꣬�һ�Crop Image��');
            J=imcrop(I);                        %��ȡ�궨
            J=imadjust(J,stretchlim(J));        %��ǿ�Աȶ�
            T=graythresh(J);                    %��ֵ��
            J=im2bw(J,T);
            J=1-J;                              %����
            [a,b]=size(J);
            x=zeros(1,b);
            D1=0;D2=0;
            for i=1:a
                x=x+J(i,:);                     %ͶӰ
            end
            for i=2:b-1                         %ȡˮƽ����
                if x(i)>1
                    if D1==0
                        D1=i-1;
                    end
                end
                if x(b+1-i)>2
                    if D2==0
                        D2=b+1-i;
                    end
                end
            end
        end
        B=str2double(get(handles.edit1,'string'));
        dpi=abs(D2-D1)/B*2.54;
        set(handles.edit2,'string',num2str(dpi,'%10.3f'));
    case 2,errordlg('���Ƚ��м���У����','Warning...');
    case 1,errordlg('���Ƚ�����ֵ�˲���','Warning...');
    case 0,errordlg('���ȴ�ͼ��','Warning...');
end
set(handles.edit7,'String','������У�����Ԫ��ͼ��');
set(handles.edit6,'String','OK');


% --- Executes on button press in pushbutton12.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit6,'String','...');
global I;
global P
switch P
    case 7,errordlg('ͼ���Ѿ���ɶ�ֵ������ֱ�Ӳ���λ��','Warning...');
    case 6,errordlg('ͼ���Ѿ���ǿ�Աȶȣ�������ò�����λ��','Warning...');
    case 5,errordlg('�Ѿ���ȡĿ�꣬������ò�����λ��','Warning...');
    case 4,
        dpi=str2num(get(handles.edit2,'string'));
        if dpi==0
            errordlg('����δ��ɣ�����ѡȡ�Ķ���㣡','Warning...');
        else P=5;
            set(handles.edit7,'String','�����ȡԪ��Ŀ��ͼ���һ�Crop Image��');
            I=imcrop(I);
            axes(handles.axes1);
            imshow(I);
            set(handles.edit7,'String','����ȡĿ����Ԫ��ͼ��');
        end
    case 3,errordlg('����ȡ�궨Ŀ�꣡','Warning...');
    case 2,errordlg('���Ƚ��м���У����','Warning...');
    case 1,errordlg('���Ƚ�����ֵ�˲���','Warning...');
    case 0,errordlg('���ȴ�ͼ��','Warning...');
end
set(handles.edit6,'String','OK');


% --- Executes on button press in pushbutton13.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit6,'String','...');
global I;
global P;
switch P
    case 7,errordlg('ͼ���Ѿ���ɶ�ֵ������ֱ�Ӳ���λ��','Warning...');
    case 6,errordlg('ͼ���Ѿ���ǿ�Աȶȣ�������ò�����λ��','Warning...');
    case 5,P=6;
        I=imadjust(I,stretchlim(I));                             %��ǿ�Աȶ�
        axes(handles.axes1);
        imshow(I);
        set(handles.edit7,'String','����ǿ�ԱȶȺ��Ԫ��ͼ��');
    case 4,errordlg('���Ƚ�ȡĿ��Ԫ����','Warning...');
    case 3,errordlg('����ȡ�궨Ŀ�꣡','Warning...');
    case 2,errordlg('���Ƚ��м���У����','Warning...');
    case 1,errordlg('���Ƚ�����ֵ�˲���','Warning...');
    case 0,errordlg('���ȴ�ͼ��','Warning...');
end
set(handles.edit6,'String','OK');


% --- Executes on button press in pushbutton12.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit6,'String','...');
global I;
global P;
switch P
    case 7,errordlg('ͼ���Ѿ���ɶ�ֵ������ֱ�Ӳ���λ��','Warning...');
    case 6,P=7;
        T=graythresh(I);
        I=im2bw(I,T);                                            %��ֵ��ͼ��
        axes(handles.axes1);
        imshow(I);
        set(handles.edit7,'String','����ֵ�����Ԫ��ͼ��');
    case 4,errordlg('����ǿ�Աȶȣ�','Warning...');
    case 4,errordlg('���Ƚ�ȡĿ��Ԫ����','Warning...');
    case 3,errordlg('����ȡ�궨Ŀ�꣡','Warning...');
    case 2,errordlg('���Ƚ��м���У����','Warning...');
    case 1,errordlg('���Ƚ�����ֵ�˲���','Warning...');
    case 0,errordlg('���ȴ�ͼ��','Warning...');
end
set(handles.edit6,'String','OK');


% --- Executes on button press in pushbutton13.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit6,'String','...');
msgbox('���裬����ϵ΢��:matlab2022')
set(handles.edit6,'String','OK');


% --- Executes on button press in pushbutton8.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit6,'String','...');
global I;
global P;
global n;
if P ~= 7
    errordlg('�ȶ�ͼ�����Ԥ������Ȼ���ټ���ߴ磡','Warning...');
else
    J=1-I;
    [a,b]=size(J);
    c=ceil(max(a,b)/50)*50;
    J(c,c)=0;
    TX=zeros(1,c);TY=zeros(c,1);
    Tx=zeros(1,c);Ty=zeros(c,1);
    D1=zeros(2);  D2=zeros(2);
    D=zeros(2);
    for i=1:c
        TX=TX+J(i,:);
        TY=TY+J(:,i);
    end
    axes(handles.axes1);
    plot(1:c,TX);hold on;
    plot(c-(1:c),TY,'r');hold on;
    set(handles.edit7,'String','������ͶӰ:��-ˮƽ����-��ֱ��');
    for i=2:c-1
        if TX(i)>1
            if D1(1,1)==0
                D1(1,1)=i-1;
            end
        end
        if TY(i)>2
            if D1(1,2)==0
                D1(1,2)=i-1;
            end
        end               %�����
        if TX(c+1-i)>2
            if D2(1,1)==0
                D2(1,1)=c+1-i;
            end
        end
        if TY(c+1-i)>0
            if D2(1,2)==0
                D2(1,2)=c+1-i;
            end
        end              %�����
    end
    plot(D1(1,1),TX(D1(1,1)+1),'k.');hold on;
    plot(D2(1,1),TX(D2(1,1)+1),'k.');hold on;
    plot(c-D1(1,2),TY(D1(1,2)+1),'k.');hold on;
    plot(c-D2(1,2),TY(D2(1,2)+1),'k.');hold on;
    for i=1:c-1          %�����
        Tx(i)=TX(i+1)-TX(i);
        Ty(i)=TY(i+1)-TY(i);
    end
    for i=2:c-1
        if Tx(i)>0&Tx(i+1)<=0
            if D1(2,1)==0
                D1(2,1)=i;
            end
        end
        if Ty(i)>0&Ty(i+1)<=0
            if D1(2,2)==0
                D1(2,2)=i;
            end
        end               %�󼫵�
        if Tx(c+1-i)<=0&Tx(c-i)>0
            if D2(2,1)==0
                D2(2,1)=c+1-i;
            end
        end
        if Ty(c+1-i)<=0&Ty(c-i)>0
            if D2(2,2)==0
                D2(2,2)=c+1-i;
            end
        end              %�Ҽ���
    end
    clc;
    plot(D1(2,1),TX(D1(2,1)+1),'r*');hold on;
    plot(D2(2,1),TX(D2(2,1)+1),'r*');hold on;
    plot(c-D1(2,2),TY(D1(2,2)+1),'b*');hold on;
    plot(c-D2(2,2),TY(D2(2,2)+1),'b*');hold on;
    dpi=str2double(get(handles.edit2,'string'));
    D=abs(D2-D1)/dpi*2.54;
    switch n
        case 0,
            set(handles.edit3,'String',num2str(D(1,1),'%10.3f'));
            set(handles.edit4,'String',num2str(D(1,2),'%10.3f'));
        case 1,
            set(handles.edit3,'String',num2str(D(2,1),'%10.3f'));
            set(handles.edit4,'String',num2str(D(2,2),'%10.3f'));
    end
    
end
set(handles.edit6,'String','OK');


% --- Executes on button press in pushbutton7.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit6,'String','...');
global I;
global P;
dpi=str2double(get(handles.edit2,'string'));
if P==0
    errordlg('���ȴ�ͼ��','Warning...');
else if (P<4)&(dpi == 0)
        errordlg('δ���зֱ��ʱ궨,���������ֱ��ʼ��㣡','Warning...');
        set(handles.edit5,'String','Lnf');
    else
        [x,y]=ginput(2);
        D=sqrt((x(1)-x(2))^2+(y(1)-y(2))^2)/dpi*2.54;
        set(handles.edit5,'String',num2str(D,'%10.3f'));
    end
end
set(handles.edit6,'String','OK');

% --- Executes on button press in pushbutton14.
function pushbutton14_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global vid;
global P;
P=8;
axes(handles.axes1);
vid=videoinput('winvideo', 1, 'YUY2_640x480');
preview(vid);


% --- Executes on button press in pushbutton15.
function pushbutton15_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc;
clear;
close all;
close(findobj('Tag','figure1'));


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes during object creation, after setting all properties.
function radiobutton1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in radiobutton1.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes during object creation, after setting all properties.
function radiobutton2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function uipanel5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes when selected object is changed in uipanel5.
function uipanel5_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uipanel5
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
global n;
switch get(eventdata.NewValue,'Tag')
    case 'radiobutton1',
        n=0;
    case 'radiobutton2'
        n=1;
end



